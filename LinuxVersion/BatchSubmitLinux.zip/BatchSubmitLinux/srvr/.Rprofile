# Things you might want to change

.First <- function(){
  source("C:\\Apache\\htdocs\\casper2\\srvr\\parm.inc");
}